# MILES BUSINESS INDIA PVT. LTD.
## DATA ANALYSIS PROJECT

### Step 1: Import Necessary Libraries


```python
pip install scikit-learn
```

    Requirement already satisfied: scikit-learn in c:\users\bhargo\anaconda3\lib\site-packages (1.5.1)Note: you may need to restart the kernel to use updated packages.
    
    Requirement already satisfied: numpy>=1.19.5 in c:\users\bhargo\anaconda3\lib\site-packages (from scikit-learn) (1.26.4)
    Requirement already satisfied: scipy>=1.6.0 in c:\users\bhargo\anaconda3\lib\site-packages (from scikit-learn) (1.13.1)
    Requirement already satisfied: joblib>=1.2.0 in c:\users\bhargo\anaconda3\lib\site-packages (from scikit-learn) (1.4.2)
    Requirement already satisfied: threadpoolctl>=3.1.0 in c:\users\bhargo\anaconda3\lib\site-packages (from scikit-learn) (3.5.0)
    


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
```

### Step 2: Load the Data


```python
# Load the CSV file into a DataFrame
df = pd.read_csv(r"C:\Users\BHARGO\Downloads\Datasets\ADFFOODS.csv")

# Display the first few rows of the DataFrame
print(df.head())
```

       Unnamed: 0  close             datetime exchange_code   high    low   open  \
    0           0  69.00  2011-01-03 09:31:00           NSE  69.00  69.00  69.00   
    1           1  69.95  2011-01-03 09:32:00           NSE  69.95  69.95  69.95   
    2           2  68.20  2011-01-03 09:33:00           NSE  68.20  68.20  68.20   
    3           3  68.35  2011-01-03 09:41:00           NSE  68.35  68.35  68.35   
    4           4  68.25  2011-01-03 09:42:00           NSE  68.25  68.25  68.25   
    
      stock_code  volume  
    0     ADFFOO     100  
    1     ADFFOO     100  
    2     ADFFOO     591  
    3     ADFFOO      50  
    4     ADFFOO     100  
    

### Step 3: Data Cleaning and Preprocessing


```python
# Check for missing values
print(df.isnull().sum())

# Drop unnecessary columns if any
df = df.drop(columns=['Unnamed: 0'])

# Convert 'datetime' column to datetime format
df['datetime'] = pd.to_datetime(df['datetime'])

# Extract date and time components
df['date'] = df['datetime'].dt.date
df['time'] = df['datetime'].dt.time
df['hour'] = df['datetime'].dt.hour
df['minute'] = df['datetime'].dt.minute
```

    Unnamed: 0       0
    close            0
    datetime         0
    exchange_code    0
    high             0
    low              0
    open             0
    stock_code       0
    volume           0
    dtype: int64
    

### Step 4: Basic Statistical Analysis


```python
# Summary statistics
print(df.describe())

# Correlation matrix
# Select only numeric columns for correlation calculation
numeric_df = df.select_dtypes(include=[np.number])

# Check for missing values and handle them (e.g., drop rows with missing values)
numeric_df = numeric_df.dropna()

# Calculate the correlation matrix
corr_matrix = numeric_df.corr()

# Plot the correlation matrix
plt.figure(figsize=(10, 8))
sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', fmt='.2f', linewidths=0.5)
plt.title('Correlation Matrix')
plt.show()
```

                   close                       datetime           high  \
    count  671172.000000                         671172  671172.000000   
    mean      359.690184  2019-11-14 21:27:45.520104704     359.916543   
    min        37.050000            2011-01-03 09:31:00      37.050000   
    25%       166.250000            2017-03-07 10:03:45     166.400000   
    50%       247.650000            2020-05-18 12:15:00     247.900000   
    75%       551.725000            2023-04-17 11:18:15     552.700000   
    max      1182.200000            2025-02-19 15:29:00    1183.700000   
    std       293.803304                            NaN     293.959810   
    
                     low           open        volume           hour  \
    count  671172.000000  671172.000000  6.711720e+05  671172.000000   
    mean      359.452210     359.683758  6.297495e+02      11.868931   
    min        37.050000      37.050000 -7.020000e+02       9.000000   
    25%       166.100000     166.250000  1.400000e+01      10.000000   
    50%       247.450000     247.650000  9.900000e+01      12.000000   
    75%       550.662500     551.512500  3.660000e+02      14.000000   
    max      1177.700000    1182.200000  1.432194e+06      19.000000   
    std       293.645281     293.805593  4.644153e+03       1.972157   
    
                  minute        cluster      30_day_MA      60_day_MA  \
    count  671172.000000  671172.000000  671143.000000  671113.000000   
    mean       28.914915       0.250779     359.699056     359.708268   
    min         0.000000       0.000000      37.691667      38.089167   
    25%        15.000000       0.000000     166.384167     166.420000   
    50%        28.000000       0.000000     247.711667     247.795000   
    75%        43.000000       1.000000     552.444167     552.315000   
    max        59.000000       2.000000    1174.710000    1171.123333   
    std        16.925491       0.433527     293.789389     293.776643   
    
            daily_return  
    count  671171.000000  
    mean        0.000010  
    min        -0.797240  
    25%        -0.000987  
    50%         0.000000  
    75%         0.000910  
    max         0.274000  
    std         0.003913  
    


    
![png](output_9_1.png)
    


### Step 5: Time Series Analysis


```python
# Plot closing prices over time
plt.figure(figsize=(12, 6))
plt.plot(df['datetime'], df['close'], label='Close Price')
plt.title('Closing Prices Over Time')
plt.xlabel('Date')
plt.ylabel('Close Price')
plt.legend()
plt.show()
```


    
![png](output_11_0.png)
    


### Step 6: Volume Analysis


```python
# Plot volume over time
plt.figure(figsize=(12, 6))
plt.plot(df['datetime'], df['volume'], label='Volume', color='orange')
plt.title('Volume Over Time')
plt.xlabel('Date')
plt.ylabel('Volume')
plt.legend()
plt.show()
```


    
![png](output_13_0.png)
    


### Step 7: Price and Volume Relationship


```python
# Scatter plot of close price vs volume
plt.figure(figsize=(10, 6))
plt.scatter(df['close'], df['volume'], alpha=0.5)
plt.title('Close Price vs Volume')
plt.xlabel('Close Price')
plt.ylabel('Volume')
plt.show()
```


    
![png](output_15_0.png)
    


### Step 8: Clustering Analysis


```python
# Select features for clustering
features = df[['close', 'volume']]

# Standardize the features
scaler = StandardScaler()
features_scaled = scaler.fit_transform(features)

# Apply KMeans clustering
kmeans = KMeans(n_clusters=3, random_state=42)
df['cluster'] = kmeans.fit_predict(features_scaled)

# Plot clusters
plt.figure(figsize=(10, 6))
sns.scatterplot(x='close', y='volume', hue='cluster', data=df, palette='viridis')
plt.title('Clustering of Close Price and Volume')
plt.xlabel('Close Price')
plt.ylabel('Volume')
plt.show()
```


    
![png](output_17_0.png)
    


### Step 9: Hourly Analysis


```python
# Group by hour and calculate average close price
hourly_avg = df.groupby('hour')['close'].mean()

# Plot average close price by hour
plt.figure(figsize=(10, 6))
hourly_avg.plot(kind='bar', color='skyblue')
plt.title('Average Close Price by Hour')
plt.xlabel('Hour')
plt.ylabel('Average Close Price')
plt.show()
```


    
![png](output_19_0.png)
    


### Step 10: Day of Week Analysis


```python
# Extract day of the week
df['day_of_week'] = df['datetime'].dt.day_name()

# Group by day of the week and calculate average close price
daily_avg = df.groupby('day_of_week')['close'].mean()

# Plot average close price by day of the week
plt.figure(figsize=(10, 6))
daily_avg.plot(kind='bar', color='lightgreen')
plt.title('Average Close Price by Day of Week')
plt.xlabel('Day of Week')
plt.ylabel('Average Close Price')
plt.show()
```


    
![png](output_21_0.png)
    


### Step 11: Moving Averages


```python
# Calculate moving averages
df['30_day_MA'] = df['close'].rolling(window=30).mean()
df['60_day_MA'] = df['close'].rolling(window=60).mean()

# Plot moving averages
plt.figure(figsize=(12, 6))
plt.plot(df['datetime'], df['close'], label='Close Price')
plt.plot(df['datetime'], df['30_day_MA'], label='30-Day MA', color='orange')
plt.plot(df['datetime'], df['60_day_MA'], label='60-Day MA', color='green')
plt.title('Moving Averages')
plt.xlabel('Date')
plt.ylabel('Price')
plt.legend()
plt.show()
```


    
![png](output_23_0.png)
    


### Step 12: Volatility Analysis


```python
# Calculate daily returns
df['daily_return'] = df['close'].pct_change()

# Plot daily returns
plt.figure(figsize=(12, 6))
plt.plot(df['datetime'], df['daily_return'], label='Daily Return', color='purple')
plt.title('Daily Returns')
plt.xlabel('Date')
plt.ylabel('Daily Return')
plt.legend()
plt.show()
```


    
![png](output_25_0.png)
    



```python

```

## Summary of Patterns Identified

1) Trend Analysis : The closing prices show a general trend over time, which can be analyzed using moving averages.

2) Volume Analysis : Volume spikes can indicate significant trading activity, often corresponding to price changes.

3) Correlation : There is a correlation between closing prices and trading volume.

4) Clustering : The data can be clustered into groups based on price and volume, revealing different market conditions.

5) Hourly Patterns : Certain hours of the day may have higher average closing prices.

6) Day of Week Patterns : Certain days of the week may have higher average closing prices.

7) Volatility : Daily returns can be used to measure the volatility of the stock.


```python

```
